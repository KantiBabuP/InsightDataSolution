package com.tweet;

import java.util.HashSet;
import java.util.Set;

public class TweetGroup {

  private Long      timeStamp   = 0L;
  private Set<Long> tweetIdList = new HashSet<Long>();

  TweetGroup(Long timeStamp, Long id) {
    this.timeStamp = timeStamp;
    this.tweetIdList.add(id);
  }

  public void updateTweetList(Long inputId) {

    if (!tweetIdList.contains(inputId))
      tweetIdList.add(inputId);
  }

  public Long getTimeStamp() {
    return timeStamp;
  }

  public void setTimeStamp(Long timeStamp) {
    this.timeStamp = timeStamp;
  }

  public Set<Long> getTweetIdList() {
    return tweetIdList;
  }

  public void setTweetIdList(Set<Long> tweetIdList) {
    if (!this.tweetIdList.containsAll(tweetIdList))
      this.tweetIdList.addAll(tweetIdList);
  }

}
