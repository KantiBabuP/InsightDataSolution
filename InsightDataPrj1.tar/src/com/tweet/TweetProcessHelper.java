package com.tweet;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.logUtil.LogUtil;
import com.second.ConnectGraph;
import com.second.Graph;

public class TweetProcessHelper {

  private Map<Long, TweetDetail>    processedTweetMapper     = new LinkedHashMap<Long, TweetDetail>();

  private TreeMap<Long, TweetGroup> sortedTweetMap           = new TreeMap<Long, TweetGroup>();
  TreeSet<Long>                     tweetsInminuteWindow     = new TreeSet<Long>();
  TreeSet<Long>                     tweetsOutsideMinutWindow = new TreeSet<Long>();
  private static final int          maxSize                  = 1000;

  public void readInputStreamInOneMinWindow(String inputpath) {
    try {
      Gson gson = new GsonBuilder().create();
      LogUtil.log("Entered");
      // LogUtil.log("Entered");
      RandomAccessFile raf;
      Long positionToRead = null;
      Long previousPos = null;
      int location = 0;
      LogUtil.log("Entered>>1");
      File f = new File(inputpath + "\\tweet_input\\inputTestData1.txt");
      File fout = new File(inputpath + "\\tweet_output\\ft2.txt");
      PrintWriter pwt = null;
      pwt = new PrintWriter(fout);
      raf = new RandomAccessFile(f, "r");
      try {

        TweetDetail twt = null;
        String readLine = null;
        Graph g = new Graph(maxSize);

        while (true) {

          while ((readLine = raf.readLine()) != null) {
            try {
              positionToRead = raf.getFilePointer();

              LogUtil.log("--" + readLine + "--");
              if (readLine != null || readLine != " " || readLine != "") {
                twt = gson.fromJson(readLine, TweetDetail.class);

                if (twt.getTimeStamp() != null)
                  LogUtil.log(">>>>" + twt.getId() + ">>>>" + twt.getHastags());

              }
              if (!processedTweetMapper.containsKey(twt.getId()) || processedTweetMapper.isEmpty()) {
                location = 5;
                processedTweetMapper.put(twt.getId(), twt);
                LogUtil.log("---" + twt.getTimeStamp());
                if (sortedTweetMap.containsKey(twt.getTimeStamp())) {
                  sortedTweetMap.get(twt.getTimeStamp()).updateTweetList(twt.getId());
                } else {
                  sortedTweetMap.put(twt.getTimeStamp(), new TweetGroup(twt.getTimeStamp(), twt.getId()));

                }
              }
            } catch (Exception e) {
              LogUtil.log("Error" + e.getMessage());
            }

          }

          readTweetsFromMinuteWindow();

          LogUtil.log("tweetsFromMinuteWindow" + tweetsInminuteWindow);
          LogUtil.log("tweetsFromMinuteWindow" + tweetsOutsideMinutWindow);

          for (Long tweet : tweetsInminuteWindow) {
            buildGraph(tweet, true, g);
          }
          for (Long tweet : tweetsOutsideMinutWindow) {
            buildGraph(tweet, false, g);
          }

          // g.printAdj();

          g.updateAverageDegree();
          g.findEffectiveSize();
          g.printEachNodeGegree();
          LogUtil.log("Print Number of Nodes " + g.getNodeList().size());
          LogUtil.log("Print Avg degree" + g.getAverageDegree());
          LogUtil.log("Before Sleeping");
          // ProcessInputFileUtil.printOutF2(g.getAverageDegree(), fout);
          pwt.flush();
          // if (g.getAverageDegree() != null)
          System.out.println("positionToRead>>" + positionToRead + "||>>previousPos=" + previousPos);
          if (previousPos != positionToRead) {
            pwt.flush();
            pwt.println(toBigDecimal(g.getAverageDegree()));
            pwt.flush();
          }
          Thread.sleep(6000);
          LogUtil.log("Have Resumed");
          // if (positionToRead > previousPos)
          previousPos = positionToRead;
          raf.seek(positionToRead);

        }

      } catch (FileNotFoundException e) {
        // TODO Auto-generated catch block
        LogUtil.log(">>readInputStreaminMinWindow--Location " + location + "Error" + e.getMessage());
      } catch (IOException e1) {
        LogUtil.log(">>readInputStreaminMinWindow--Location " + location + "Error" + e1.getMessage());
      } catch (InterruptedException e2) { // TODO Auto-generated catch block
        LogUtil.log(">>readInputStreaminMinWindow--Location " + location + "Error" + e2.getMessage());
      }
      raf.close();
      pwt.close();
    } catch (Exception e) {
      LogUtil.log("Error" + e.getMessage());
    }
  }

  public String toBigDecimal(double input) {
    BigDecimal bd = new BigDecimal(input);
    bd = bd.setScale(2, BigDecimal.ROUND_HALF_UP);
    return bd.toString();
  }

  public void buildGraph(Long tweet, boolean isBuildOrUpdate, Graph g) {
    TweetDetail td = null;
    if (sortedTweetMap.containsKey(tweet)) {
      TweetGroup tg = sortedTweetMap.get(tweet);
      for (Long key : tg.getTweetIdList()) {
        if (processedTweetMapper.containsKey(key)) {
          td = processedTweetMapper.get(key);
          LogUtil.log("Extracted Tags:" + td.getHashTagList());
          if (isBuildOrUpdate)
            ConnectGraph.extractConnections(td.getHashTagList(), g, isBuildOrUpdate);
          else {
            ConnectGraph.extractConnections(td.getHashList(), g, isBuildOrUpdate);
          }
        }
      }
    }
  }

  public static void printoutputF1(Map<Long, TweetDetail> outputMap) {

    File output = new File("D:\\input\\ft1.txt");
    File output_2 = new File("D:\\input\\ft2.txt");
    int location = 0;

    try {
      FileWriter fop = new FileWriter(output);
      FileWriter fop_2 = new FileWriter(output_2);
      fop.flush();
      fop_2.flush();
      location = 7;
      BufferedWriter bwrt = new BufferedWriter(fop);
      BufferedWriter bwrt_2 = new BufferedWriter(fop_2);
      PrintWriter pwt = new PrintWriter(fop_2);
      LogUtil.log("Ouput>> " + outputMap.size());
      location = 8;
      for (Long key : outputMap.keySet()) {
        LogUtil.log("-->>>key>>" + key);
        bwrt.write(outputMap.get(key).toString() + "\n");
        outputMap.get(key).setHastags();
        if (outputMap.get(key).getHashTagList().size() != 0) {

          LogUtil.log(">>" + "-----" + outputMap.get(key).getHashTagList());
          LogUtil.log(">>" + "-----" + outputMap.get(key).getHashTagList());
          LogUtil.log(">>" + "-----" + outputMap.get(key).getHashTagList());
          // bwrt_2.write(outputMap.get(key).getHashTagList().size() + "\n");
          // outputMap.get(key).getHashtags();
          pwt.flush();
          pwt.println(outputMap.get(key).getHashtags());
          pwt.flush();
        }
        // LogUtil.log(">>" + outputMap.get(key).getHastags());

      }

      fop.flush();
      fop_2.flush();
      location = 10;
      bwrt.close();
      bwrt_2.close();
      pwt.close();
      fop.close();
      fop_2.close();

    } catch (Exception e) {
      LogUtil.log("Method : printoutputF1 : Errorat location" + location + e.getMessage());
    }

  }

  public TreeSet<Long> readTweetsFromMinuteWindow() {
    Long recentTimeStamp = sortedTweetMap.lastKey();
    tweetsOutsideMinutWindow.clear();
    if (!tweetsInminuteWindow.isEmpty())
      tweetsOutsideMinutWindow.addAll(tweetsInminuteWindow);

    tweetsInminuteWindow.clear();
    LogUtil.log("<<<<<<sortedTweetMap.descendingKeySet()>>>>>>>>>>" + sortedTweetMap.descendingKeySet());
    for (Long key : sortedTweetMap.descendingKeySet()) {
      LogUtil.log("recentTimeStamp>" + recentTimeStamp + "key>>" + key + "recentTimeStamp - key"
          + (recentTimeStamp - key));
      if ((recentTimeStamp - key) < 60000) {
        tweetsInminuteWindow.add(key);
        tweetsOutsideMinutWindow.remove(key);
      } else {
        break;
      }
    }
    return tweetsInminuteWindow;

  }

  public void disconnectOldConnections() {

  }

  public Map<Long, TweetDetail> getProcessedTweetMapper() {
    return processedTweetMapper;
  }

  public void setProcessedTweetMapper(Map<Long, TweetDetail> processedTweetMapper) {
    this.processedTweetMapper = processedTweetMapper;
  }

}
