package com.tweet;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.logUtil.LogUtil;

public class TweetDetail {
  private String       text;
  private String       created_at;
  private String       hashtags     = "";
  private List<String> hashTagList  = new ArrayList<String>();
  private Long         id;
  private String       clenedPhrase = "";
  public static int    uniCodeCount = 0;

  public String getHastags() {

    return hashtags;
  }

  public void setHastags() {

    List<String> processHtags = extractHashTagList(getText());
    this.setHashTagList(processHtags);
    if (processHtags.size() > 0) {
      for (String hTag : processHtags) {
        this.hashtags = this.hashtags + hTag;
      }
    }

  }

  public String getText() {
    return text;
  }

  public void setText(String text) {
    this.text = text;
  }

  public String getCreated_at() {
    return created_at;
  }

  public void setCreated_at(String created_at) {
    this.created_at = created_at;
  }

  public String toString() {
    String cleaned = "";
    if (text != null)
      cleaned = matchAndReplaceNonEnglishChar(text);
    clenedPhrase = cleaned + " (timestamp: " + created_at + ")" + hashtags;
    return String.format("%s", clenedPhrase);
  }

  public String matchAndReplaceNonEnglishChar(String inputText) {
    int location = 0;
    String newsrcdta = null;
    String loc = "init";
    StringBuilder processed = new StringBuilder();
    processed.append("");

    try {
      if (TweetUtil.check(inputText.toString()))
        uniCodeCount++;
      location++;
      inputText = inputText.replaceAll("[^\\p{ASCII}]", "");
      location++;
      inputText = inputText.replaceAll("\\s+", " ");
      location++;
      char[] array = inputText.toCharArray();
      location++;
      // System.out.println("---" + array.toString());
      loc = "XX";
      for (int i = 0; i < array.length; i++) {
        loc = "inside loop-1";
        boolean bISO = Character.isISOControl(array[i]);
        boolean bIgnorable = Character.isIdentifierIgnorable(array[i]);
        boolean IsalphraNumeric = Character.isIdentifierIgnorable(array[i]);
        loc = "inside loop-2";
        if (bISO || bIgnorable || IsalphraNumeric) {
          array[i] = ' ';
        } else {
          processed.append(array[i]);
        }
      }

    } catch (Exception e) {
      LogUtil
          .log(loc + "Error from : matchAndReplaceNonEnglishChar-- " + location + " --" + e.getMessage() + inputText);
    }

    return processed.toString();
  }

  public List<String> getHashList() {

    return extractHashTagList(getText());
  }

  public List<String> extractHashTagList(String input) {

    String[] list = input.split(" ");
    String output = "";

    for (int i = 0; i < list.length; i++) {

      if (list[i].indexOf("#") == 0) {
        System.out.println(">>Indexzero>>" + list[i]);

        if (!isHashTagDuplicate(list[i])) {
          output = output + " " + list[i];
          hashTagList.add(list[i]);
        }

      }

    }
    System.out.println("<<<<output>>" + hashTagList);

    return hashTagList;
  }

  public boolean isHashTagDuplicate(String hTag) {
    if (hashTagList.size() == 0) {
      return false;
    }
    for (String tag : hashTagList) {
      if (tag.equalsIgnoreCase(hTag)) {
        return true;
      }
    }
    return false;
  }

  public boolean isHashTagPresent(String input) {
    String[] list = input.split(" ");
    boolean output = false;
    for (int i = 0; i < list.length; i++) {
      if (list[i].indexOf("#") == 0) {
        output = true;
        break;
      }

    }

    return output;
  }

  public Long getTimeStamp() {

    String inputDate = this.created_at;
    SimpleDateFormat sdf = new SimpleDateFormat("E MMM dd HH:mm:ss Z yyyy");
    Date outputDate = null;
    try {
      outputDate = sdf.parse(inputDate);
    } catch (ParseException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }

    Calendar date = Calendar.getInstance();
    date.setTime(outputDate);

    return outputDate.getTime();
  }

  public List<String> getHashTagList() {
    extractHashTagList(getText());
    return hashTagList;
  }

  public void setHashTagList(List<String> hashTagList) {
    this.hashTagList = hashTagList;
  }

  public String getHashtags() {
    return hashtags;
  }

  public void setHashtags(String hashtags) {
    this.hashtags = hashtags;
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }
}