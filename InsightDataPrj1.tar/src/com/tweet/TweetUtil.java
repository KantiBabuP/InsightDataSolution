package com.tweet;

import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;

public class TweetUtil {

  static CharsetEncoder asciiEncoder = Charset.forName("US-ASCII").newEncoder(); // or "ISO-8859-1" for ISO Latin 1

  public static boolean isPureAscii(String v) {
    return asciiEncoder.canEncode(v);
  }

  public static boolean check(String input) {
    char[] array = input.toCharArray();

    for (int i = 0; i < array.length; i++) {
      int equalNum = (int) array[i];
      // System.out.println("Character" + array[i] + "Equivalent number" + equalNum);
      if (equalNum > 127) {
        // System.out.println("I am Uni char");
        return true;
      }
    }

    return false;

  }

  public static boolean checkPhrase(String input) {
    System.out.println("----------------------------------------->Phrase" + input);
    String[] word = input.split(" ");
    for (int i = 0; i < input.length(); i++) {
      if (!isPureAscii(word[i])) {
        System.out.println(">>>>>>>>>>>>>>>>>>>>>>>" + word[i]);
        return true;

      }
    }

    return false;
  }
}