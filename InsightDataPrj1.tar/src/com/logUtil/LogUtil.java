package com.logUtil;

public class LogUtil {

  static boolean logEnable = true;

  public static void log(String mesg) {
    if (isLogEnable())
      System.out.println(mesg);
  }

  public static boolean isLogEnable() {
    return logEnable;
  }

  public static void setLogEnable(boolean enable) {
    logEnable = enable;
  }

}
