package com.filehandle;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.LinkedHashMap;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.logUtil.LogUtil;
import com.tweet.TweetDetail;

public class ProcessFeatureOneUtil {

  String                                inputFilePath;
  private static Map<Long, TweetDetail> processedTweetMapper = new LinkedHashMap<Long, TweetDetail>();

  public static void readFileFeature1(String path) {
    int location = 0;
    try {
      File file = new File(path + "//tweet_input//inputTestData1.txt");

      Gson gson = new GsonBuilder().create();
      processedTweetMapper.clear();

      FileReader fr = new FileReader(file);
      BufferedReader reader = new BufferedReader(fr);
      String inputLine = null;
      TweetDetail twt = new TweetDetail();

      int counter = 0;
      while ((inputLine = reader.readLine()) != null) {
        try {

          location = 2;
          // System.out.println("inputLine" + inputLine);

          if (inputLine != null || inputLine != " " || inputLine != "") {
            counter++;
            twt = gson.fromJson(inputLine, TweetDetail.class);
            location = 3;

            location = 4;
            if (!processedTweetMapper.containsKey(twt.getId()) || processedTweetMapper.isEmpty()) {
              location = 5;
              processedTweetMapper.put(twt.getId(), twt);
              LogUtil.log("---" + twt.toString());

            }

          }

        } catch (Exception e) {
          System.out.println("Error for Line" + counter + e.getMessage() + "At location " + location);
        }

      }
      System.out.println("processedTweetMapper>> SIZE >>" + processedTweetMapper.size());
      for (Long key : processedTweetMapper.keySet()) {
        System.out.println("key>>" + key);
      }
      printoutputF1(path);

      fr.close();
      reader.close();

    } catch (Exception e) {
      System.out.println("Errorat location" + location + e.getMessage());
    }
  }

  public static void printoutputF1(String path) {

    File output = new File(path + "//tweet_output//ft1.txt");

    int location = 0;

    try {
      // FileWriter fop = new FileWriter(output);

      // / fop.flush();
      if (output.exists()) {

        output.createNewFile();

      }

      location = 1;
      FileOutputStream fop = new FileOutputStream(output);
      PrintWriter pwt = new PrintWriter(fop);
      location = 2;
      location = 3;
      if (!processedTweetMapper.isEmpty()) {
        location = 4;
        for (Long key : processedTweetMapper.keySet()) {
          try {
            location = 5;

            pwt.flush();
            pwt.println(processedTweetMapper.get(key).toString());
            pwt.flush();
          } catch (Exception e) {
            System.out.println("Error  for Key" + key);
          }
        }

        // }
      }
      location = 4;
      // fop.flush();
      location = 10;
      pwt.println(TweetDetail.uniCodeCount + "tweets contained unicode ");
      pwt.close();
      // fop.close();

    } catch (Exception e) {
      System.out.println("Method : printoutputF1 : Errorat location" + location + e.getMessage());
    }

  }
}
