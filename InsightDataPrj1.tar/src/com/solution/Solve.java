package com.solution;

import com.filehandle.ProcessFeatureOneUtil;
import com.tweet.TweetProcessHelper;

public class Solve {

  public static void main(String args[]) {

    System.out.println("Enter Feature1 :1 \n Feature2 :2 \n");
    int firstArg;

    if (args.length > 0) {
      try {
        firstArg = Integer.parseInt(args[0]);
        String secondArg = args[1];
        secondArg = secondArg.replaceAll("/", "//");
        if (firstArg == 1)
          ProcessFeatureOneUtil.readFileFeature1(secondArg);
        else if (firstArg == 2) {
          TweetProcessHelper process1 = new TweetProcessHelper();
          process1.readInputStreamInOneMinWindow(secondArg);
        } else {
          System.out.println("Please enter proper option first Argument !");
        }
      } catch (NumberFormatException e) {
        System.err.println("Argument" + args[0] + " must be an integer.");
        System.exit(1);
      }
    }

    // TweetProcessHelper process1 = new TweetProcessHelper();
    // process1.readInputStreamInOneMinWindow();

  }
}
