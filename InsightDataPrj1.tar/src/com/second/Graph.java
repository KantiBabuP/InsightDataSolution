package com.second;

import java.util.ArrayList;
import java.util.List;

public class Graph {

  int[][]           adjecenyMatrix;
  int[][]           edgeCountMatrix;                           ;
  List<Node>        nodeList          = new ArrayList<Node>();
  int               size;
  public List<Pair> pairList          = new ArrayList<Pair>();
  Integer           averageDegree     = 0;
  Integer           effectiveListSize = 0;

  public Graph(int size) {
    this.size = size;
    adjecenyMatrix = new int[this.size][this.size];
  }

  public void appendToGraph(Node one, Node two, boolean isAdd) {
    int positionOne = -9;
    int positionTwo = -9;
    for (Node traverse : nodeList) {
      if (traverse.equals(one)) {
        positionOne = nodeList.indexOf(one);
      } else if (traverse.equals(two)) {
        positionTwo = nodeList.indexOf(two);
      }
    }
    if (positionOne < 0) {
      nodeList.add(one);
      positionOne = nodeList.indexOf(one);
    }
    if (positionTwo < 0) {
      nodeList.add(two);
      positionTwo = nodeList.indexOf(two);
    }
    if (isAdd) {
      adjecenyMatrix[positionOne][positionTwo] = 1;
    } else {
      adjecenyMatrix[positionOne][positionTwo] = 0;
    }

  }

  public void printAdj() {
    System.out.print("\t");
    for (int i = 0; i < getNodeList().size(); i++) {
      System.out.print(nodeList.get(i).getName() + " ");
    }
    System.out.println("");
    for (int i = 0; i < this.size; i++) {
      System.out.println("");
      for (int j = 0; j < this.size; j++) {
        System.out.print("\t" + this.adjecenyMatrix[i][j]);
      }
    }
  }

  public List<Node> getNodeList() {
    return nodeList;
  }

  public void setNodeList(List<Node> nodeList) {
    this.nodeList = nodeList;
  }

  public int getCalcualtion() {
    int sum = 0;
    for (int i = 0; i < this.size; i++)
      for (int j = 0; j < this.size; j++) {
        sum = sum + adjecenyMatrix[i][j];
      }
    return sum;

  }

  public void setAdjecenyMatrix(int[][] adjecenyMatrix) {
    this.adjecenyMatrix = adjecenyMatrix;
  }

  public void printEachNodeGegree() {
    for (int i = 0; i < nodeList.size(); i++) {
      System.out.println("Node [" + i + "]>>" + nodeList.get(i).getName() + " Degree is :"
          + nodeList.get(i).getDegree());
    }
  }

  public void updateAverageDegree() {
    edgeCountMatrix = new int[size][size];
    int sum = 0;
    averageDegree = 0;
    for (int i = 0; i < nodeList.size(); i++) {
      for (int j = 0; j < nodeList.size(); j++) {
        edgeCountMatrix[i][j] = this.adjecenyMatrix[j][i];
      }
    }
    for (int i = 0; i < nodeList.size(); i++) {
      for (int j = 0; j < nodeList.size(); j++) {
        edgeCountMatrix[i][j] = edgeCountMatrix[i][j] + this.adjecenyMatrix[i][j];
      }
    }
    for (int i = 0; i < nodeList.size(); i++) {
      sum = 0;
      for (int j = 0; j < nodeList.size(); j++) {
        // edgeCountMatrix[i][size] =
        sum = sum + edgeCountMatrix[i][j];
      }
      averageDegree = averageDegree + sum;
      nodeList.get(i).setDegree(sum);

    }
    System.out.println("AverageDegree>>" + averageDegree);
    // return averageDegree;

  }

  public void findEffectiveSize() {
    this.effectiveListSize = 0;
    for (int i = 0; i < nodeList.size(); i++) {
      if (nodeList.get(i).getDegree() > 0)
        this.effectiveListSize = this.effectiveListSize + 1;
    }
    System.out.println("effectiveListSize>>" + effectiveListSize);

  }

  public double getAverageDegree() {

    if (effectiveListSize != 0)
      return (double) (averageDegree.doubleValue() / effectiveListSize.doubleValue());
    else
      return averageDegree;
  }

  public void setAverageDegree(int averageDegree) {
    this.averageDegree = averageDegree;
  }
}
