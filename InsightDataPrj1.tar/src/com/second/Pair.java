package com.second;

public class Pair {

  Node FirstNode;
  Node SecondNode;

  public Node getFirstNode() {
    return FirstNode;
  }

  public void setFirstNode(Node firstNode) {
    FirstNode = firstNode;
  }

  public Node getSecondNode() {
    return SecondNode;
  }

  public void setSecondNode(Node secondNode) {
    SecondNode = secondNode;
  }

  Pair(String one, String two) {
    this.FirstNode = new Node(one);
    this.SecondNode = new Node(two);

  }

}
