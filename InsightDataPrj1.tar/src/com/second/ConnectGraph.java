package com.second;

import java.util.ArrayList;
import java.util.List;

public class ConnectGraph {

  public static void extractConnections(List<String> hashTagList, Graph g, boolean isbuildOrUpdate) {

    Pair generatedPair;
    List<Pair> pairList = new ArrayList<Pair>();

    for (int i = 0; i < hashTagList.size(); i++)
      System.out.println(">>>Htokens-I=" + i + "--" + hashTagList.get(i));
    for (int i = 0; i < hashTagList.size() - 1; i++) {
      for (int j = i + 1; j < hashTagList.size(); j++) {
        System.out.println("FirstNode" + hashTagList.get(i) + "SecondNode" + hashTagList.get(j));
        generatedPair = new Pair(hashTagList.get(i), hashTagList.get(j));
        pairList.add(generatedPair);

      }
    }
    for (int i = 0; i < pairList.size(); i++)
      System.out.println("}}}" + pairList.get(i).getFirstNode().getName() + "SecondNode"
          + pairList.get(i).getSecondNode().getName());
    for (int i = 0; i < pairList.size(); i++)
      g.appendToGraph(pairList.get(i).getFirstNode(), pairList.get(i).getSecondNode(), isbuildOrUpdate);

  }
}
