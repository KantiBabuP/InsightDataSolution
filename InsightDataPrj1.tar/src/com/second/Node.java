package com.second;

public class Node {

  String name;
  int    degree = 0;

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  Node(String name) {
    this.name = name;
  }

  @Override
  public boolean equals(Object obj) {
    // TODO Auto-generated method stub
    Node n = (Node) obj;
    if (name.equals(n.getName())) {
      return true;
    }

    return false;
  }

  /*
   * public boolean equals(Object obj){ System.out.println("In equals"); if (obj instanceof Node) { Node n = (Node) obj;
   * return (n.getName().equals(this.getName())); } else { return false; } }
   */

  public boolean equalsObj(String input) {
    if (name.equals(input)) {
      return true;
    }

    return false;
  }

  public int getDegree() {
    return degree;
  }

  public void setDegree(int degree) {
    this.degree = degree;
  }

}
